package com.example.demo;

public class HeroeNotFoundException extends RuntimeException {

    public HeroeNotFoundException(Long id) {
        super("Heroe id not found : " + id);
    }

}
