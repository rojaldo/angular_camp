package com.example.demo;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "heroe")
public class Heroe {

    @Id
    @GeneratedValue
    private Long id;

    private String name;
    private String description;

    public Heroe() {
    }

    public Heroe(Long id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public Heroe(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Heroe{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                '}';
    }

}
