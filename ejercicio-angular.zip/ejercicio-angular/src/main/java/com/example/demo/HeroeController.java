package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;

@RestController
public class HeroeController {

    @Autowired
    private HeroeRepository heroeRepository;

    // Find all
    @GetMapping("/api/v1/heroes")
    List<Heroe> findAll() {
        return heroeRepository.findAll();
    }

    // Save
    @PostMapping("/api/v1/heroes")
    // return 201 instead of 200
    @ResponseStatus(HttpStatus.CREATED)
    Heroe newHeroe(@RequestBody Heroe newHeroe) {
        return heroeRepository.save(newHeroe);
    }

    // Find by id
    @GetMapping("/api/v1/heroes/{id}")
    Heroe findOne(@PathVariable Long id) {
        Heroe myHeroe = heroeRepository.findById(id).orElseThrow(() -> new HeroeNotFoundException(id));
        return myHeroe;
    }

    @DeleteMapping("/api/v1/heroes/{id}")
    void deleteHeroe(@PathVariable Long id) {
        heroeRepository.deleteById(id);
    }

}
