package com.example.demo;

import java.util.Set;

public class HeroeUnSupportedFieldPatchException extends RuntimeException {

    public HeroeUnSupportedFieldPatchException(Set<String> keys) {
        super("Field " + keys.toString() + " update is not allowed.");
    }

}
