package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import java.math.BigDecimal;


@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Bean
    CommandLineRunner initDatabase(HeroeRepository heroeRepository) {
        return args -> {
            heroeRepository.save(new Heroe("Superman", "Man of the Steel"));
            heroeRepository.save(new Heroe("Spiderman", "The Human Spider"));
            heroeRepository.save(new Heroe("Iron Man", "Tony Stark"));
        };
    }

}
